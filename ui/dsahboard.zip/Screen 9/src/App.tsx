import { useEffect } from "react";
import {
  AlertCircle,
  ChevronRight,
  LayoutDashboard,
  LineChart as LucideLineChart,
  RefreshCw,
  Sparkles,
  Stethoscope,
  Zap,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[956px] bg-neutral-950 text-neutral-50 flex w-full">
          <aside className="shrink-0 bg-neutral-900/40 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col justify-between w-65">
            <div className="space-y-8">
              <div className="flex items-center gap-3">
                <div className="size-11 shadow-[0_0_0_1px_oklch(1_0_0/.08)] rounded-2xl bg-neutral-200 text-neutral-900 flex justify-center items-center">
                  <Sparkles className="size-5" />
                </div>
                <div className="space-y-0.5">
                  <div className="leading-none font-semibold text-lg leading-7">
                    Sentinel
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5">
                    Incident intelligence
                  </div>
                </div>
              </div>
              <nav className="flex flex-col justify-start items-stretch gap-2">
                <button className="font-medium shadow-[inset_0_0_0_1px_oklch(1_0_0/.06)] rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <LayoutDashboard className="size-4" />
                  Dashboard
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <AlertCircle className="size-4" />
                  Incidents
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Zap className="size-4" />
                  Pipelines
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Stethoscope className="size-4" />
                  Diagnose
                </button>
              </nav>
            </div>
            <div className="shadow-[0_12px_40px_oklch(0_0_0/.25)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
              <div className="flex items-center gap-3">
                <div className="size-10 font-semibold rounded-full bg-neutral-200 text-neutral-900 text-sm leading-5 flex justify-center items-center">
                  AM
                </div>
                <div className="min-w-0">
                  <div className="truncate font-medium text-sm leading-5">
                    Alex Morgan
                  </div>
                  <div className="text-[#a1a1a1] text-xs leading-4">
                    On call
                  </div>
                </div>
              </div>
            </div>
          </aside>
          <main className="px-8 py-6 flex-1 overflow-hidden">
            <div className="max-w-[860px] flex mx-auto flex-col gap-6 h-full">
              <div className="flex justify-between items-center">
                <div>
                  <h1 className="font-semibold text-3xl leading-9 tracking-tight">
                    Dashboard
                  </h1>
                  <p className="text-[#a1a1a1] text-sm leading-5 mt-1">
                    Monitor incident health, trends, and response performance
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="inline-flex font-medium rounded-full bg-neutral-900 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 items-center gap-2">
                    <span className="size-2 shadow-[0_0_0_4px_oklch(0.696_0.17_162.48/.12)] rounded-full bg-emerald-400" />
                    AI enabled
                  </div>
                  <button className="inline-flex font-medium shadow-[inset_0_0_0_1px_oklch(1_0_0/.06)] rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 px-4 py-2.5 items-center gap-2">
                    <RefreshCw className="size-4" />
                    Refresh
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-6 gap-4">
                <div className="col-span-1 shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="uppercase text-[#a1a1a1] text-xs leading-4 tracking-[3.2px]">
                        Total Incidents
                      </div>
                      <div className="font-semibold text-3xl leading-9 mt-3">
                        1,284
                      </div>
                    </div>
                    <div className="font-medium rounded-full bg-emerald-500/10 text-emerald-400 text-xs leading-4 px-2 py-1">
                      +12%
                    </div>
                  </div>
                  <div className="bg-[linear-gradient(90deg,transparent_0%,transparent_8%,oklch(0.488_0.243_264.376/.18)_8%,oklch(0.488_0.243_264.376/.18)_18%,transparent_18%,transparent_26%,oklch(0.488_0.243_264.376/.28)_26%,oklch(0.488_0.243_264.376/.28)_38%,transparent_38%,transparent_46%,oklch(0.488_0.243_264.376/.22)_46%,oklch(0.488_0.243_264.376/.22)_58%,transparent_58%,transparent_66%,oklch(0.488_0.243_264.376/.34)_66%,oklch(0.488_0.243_264.376/.34)_78%,transparent_78%,transparent_100%)] rounded-lg mt-6 h-10" />
                </div>
                <div className="col-span-1 shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="uppercase text-[#a1a1a1] text-xs leading-4 tracking-[3.2px]">
                        Open
                      </div>
                      <div className="font-semibold text-3xl leading-9 mt-3">
                        42
                      </div>
                    </div>
                    <div className="font-medium rounded-full bg-emerald-500/10 text-emerald-400 text-xs leading-4 px-2 py-1">
                      -8%
                    </div>
                  </div>
                  <div className="bg-[linear-gradient(90deg,transparent_0%,transparent_10%,oklch(0.488_0.243_264.376/.18)_10%,oklch(0.488_0.243_264.376/.18)_22%,transparent_22%,transparent_34%,oklch(0.488_0.243_264.376/.3)_34%,oklch(0.488_0.243_264.376/.3)_48%,transparent_48%,transparent_60%,oklch(0.488_0.243_264.376/.22)_60%,oklch(0.488_0.243_264.376/.22)_72%,transparent_72%,transparent_100%)] rounded-lg mt-6 h-10" />
                </div>
                <div className="col-span-1 shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="uppercase text-[#a1a1a1] text-xs leading-4 tracking-[3.2px]">
                        Resolved
                      </div>
                      <div className="font-semibold text-3xl leading-9 mt-3">
                        1,102
                      </div>
                    </div>
                    <div className="font-medium rounded-full bg-emerald-500/10 text-emerald-400 text-xs leading-4 px-2 py-1">
                      +18%
                    </div>
                  </div>
                  <div className="bg-[linear-gradient(90deg,transparent_0%,transparent_12%,oklch(0.488_0.243_264.376/.18)_12%,oklch(0.488_0.243_264.376/.18)_24%,transparent_24%,transparent_36%,oklch(0.488_0.243_264.376/.28)_36%,oklch(0.488_0.243_264.376/.28)_50%,transparent_50%,transparent_62%,oklch(0.488_0.243_264.376/.22)_62%,oklch(0.488_0.243_264.376/.22)_74%,transparent_74%,transparent_100%)] rounded-lg mt-6 h-10" />
                </div>
                <div className="col-span-1 shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="uppercase text-[#a1a1a1] text-xs leading-4 tracking-[3.2px]">
                        Recurring
                      </div>
                      <div className="font-semibold text-3xl leading-9 mt-3">
                        86
                      </div>
                    </div>
                    <div className="font-medium rounded-full bg-amber-500/10 text-amber-400 text-xs leading-4 px-2 py-1">
                      +4%
                    </div>
                  </div>
                  <div className="bg-[linear-gradient(90deg,transparent_0%,transparent_14%,oklch(0.488_0.243_264.376/.18)_14%,oklch(0.488_0.243_264.376/.18)_28%,transparent_28%,transparent_40%,oklch(0.488_0.243_264.376/.3)_40%,oklch(0.488_0.243_264.376/.3)_54%,transparent_54%,transparent_68%,oklch(0.488_0.243_264.376/.22)_68%,oklch(0.488_0.243_264.376/.22)_82%,transparent_82%,transparent_100%)] rounded-lg mt-6 h-10" />
                </div>
                <div className="col-span-1 shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="uppercase text-[#a1a1a1] text-xs leading-4 tracking-[3.2px]">
                        Avg Confidence
                      </div>
                      <div className="font-semibold text-3xl leading-9 mt-3">
                        91%
                      </div>
                    </div>
                    <div className="font-medium rounded-full bg-emerald-500/10 text-emerald-400 text-xs leading-4 px-2 py-1">
                      +2%
                    </div>
                  </div>
                  <div className="bg-[linear-gradient(90deg,transparent_0%,transparent_12%,oklch(0.488_0.243_264.376/.18)_12%,oklch(0.488_0.243_264.376/.18)_20%,transparent_20%,transparent_34%,oklch(0.488_0.243_264.376/.34)_34%,oklch(0.488_0.243_264.376/.34)_44%,transparent_44%,transparent_58%,oklch(0.488_0.243_264.376/.24)_58%,oklch(0.488_0.243_264.376/.24)_70%,transparent_70%,transparent_100%)] rounded-lg mt-6 h-10" />
                </div>
                <div className="col-span-1 shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="uppercase text-[#a1a1a1] text-xs leading-4 tracking-[3.2px]">
                        MTTR
                      </div>
                      <div className="font-semibold text-3xl leading-9 mt-3">
                        42m
                      </div>
                    </div>
                    <div className="font-medium rounded-full bg-emerald-500/10 text-emerald-400 text-xs leading-4 px-2 py-1">
                      -11%
                    </div>
                  </div>
                  <div className="bg-[linear-gradient(90deg,transparent_0%,transparent_10%,oklch(0.488_0.243_264.376/.16)_10%,oklch(0.488_0.243_264.376/.16)_18%,transparent_18%,transparent_30%,oklch(0.488_0.243_264.376/.26)_30%,oklch(0.488_0.243_264.376/.26)_42%,transparent_42%,transparent_56%,oklch(0.488_0.243_264.376/.2)_56%,oklch(0.488_0.243_264.376/.2)_68%,transparent_68%,transparent_100%)] rounded-lg mt-6 h-10" />
                </div>
              </div>
              <div className="grid grid-cols-12 gap-4">
                <div className="col-span-7 shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-lg leading-7">
                        Recent Incidents
                      </div>
                      <div className="text-[#a1a1a1] text-sm leading-5">
                        Latest signals from production
                      </div>
                    </div>
                    <div className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                      Live feed
                    </div>
                  </div>
                  <div className="space-y-3 mt-5">
                    <div className="rounded-2xl bg-neutral-950/40 border-white/10 border-1 border-solid p-4">
                      <div className="flex justify-between items-start gap-4">
                        <div className="space-y-2">
                          <div className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                            12m ago
                          </div>
                          <div className="font-medium text-base leading-6">
                            Checkout latency spike causing payment failures
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <span className="rounded-full bg-red-500/10 text-red-300 text-xs leading-4 px-2.5 py-1">
                              Investigating
                            </span>
                            <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                              Platform: Web
                            </span>
                            <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                              Pipeline: Payments
                            </span>
                          </div>
                        </div>
                        <ChevronRight className="size-4 text-[#a1a1a1] mt-1" />
                      </div>
                    </div>
                    <div className="rounded-2xl bg-neutral-950/40 border-white/10 border-1 border-solid p-4">
                      <div className="flex justify-between items-start gap-4">
                        <div className="space-y-2">
                          <div className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                            34m ago
                          </div>
                          <div className="font-medium text-base leading-6">
                            Schema drift in profile sync jobs
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <span className="rounded-full bg-amber-500/10 text-amber-300 text-xs leading-4 px-2.5 py-1">
                              Acknowledged
                            </span>
                            <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                              Category: Data Quality
                            </span>
                            <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                              Pipeline: profile-sync
                            </span>
                          </div>
                        </div>
                        <ChevronRight className="size-4 text-[#a1a1a1] mt-1" />
                      </div>
                    </div>
                    <div className="rounded-2xl bg-neutral-950/40 border-white/10 border-1 border-solid p-4">
                      <div className="flex justify-between items-start gap-4">
                        <div className="space-y-2">
                          <div className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                            1h ago
                          </div>
                          <div className="font-medium text-base leading-6">
                            Worker pool exhaustion during peak traffic
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <span className="rounded-full bg-emerald-500/10 text-emerald-300 text-xs leading-4 px-2.5 py-1">
                              Resolved
                            </span>
                            <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                              Category: Infra
                            </span>
                            <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                              Pipeline: checkout-stream
                            </span>
                          </div>
                        </div>
                        <ChevronRight className="size-4 text-[#a1a1a1] mt-1" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-span-5 flex flex-col gap-4">
                  <div className="shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-semibold text-lg leading-7">
                          Incidents over time
                        </div>
                        <div className="text-[#a1a1a1] text-sm leading-5">
                          Trend line with hoverable points
                        </div>
                      </div>
                      <LucideLineChart className="size-4 text-[#a1a1a1]" />
                    </div>
                    <div className="rounded-2xl bg-neutral-950/40 border-white/10 border-1 border-solid mt-5 p-4 h-55">
                      <div className="flex items-end gap-3 h-full">
                        <div className="h-[28%] rounded-t-lg bg-neutral-200/20 w-full" />
                        <div className="h-[42%] rounded-t-lg bg-neutral-200/30 w-full" />
                        <div className="h-[36%] rounded-t-lg bg-neutral-200/25 w-full" />
                        <div className="h-[58%] rounded-t-lg bg-neutral-200/35 w-full" />
                        <div className="h-[48%] rounded-t-lg bg-neutral-200/30 w-full" />
                        <div className="h-[66%] rounded-t-lg bg-neutral-200/40 w-full" />
                        <div className="h-[52%] rounded-t-lg bg-neutral-200/30 w-full" />
                        <div className="h-[74%] rounded-t-lg bg-neutral-200/45 w-full" />
                        <div className="h-[60%] rounded-t-lg bg-neutral-200/35 w-full" />
                        <div className="h-[82%] rounded-t-lg bg-neutral-200/50 w-full" />
                      </div>
                    </div>
                  </div>
                  <div className="shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                    <div className="font-semibold text-lg leading-7">
                      By Root Cause
                    </div>
                    <div className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">Timeouts</span>
                          <span className="text-neutral-50">42</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[78%] rounded-full bg-violet-500 h-full" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">Schema drift</span>
                          <span className="text-neutral-50">31</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[58%] rounded-full bg-violet-400 h-full" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">Capacity</span>
                          <span className="text-neutral-50">24</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[44%] rounded-full bg-violet-300 h-full" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">Auth</span>
                          <span className="text-neutral-50">18</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[34%] rounded-full bg-violet-200 h-full" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="shadow-[0_12px_40px_oklch(0_0_0/.22)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                    <div className="font-semibold text-lg leading-7">
                      By Platform
                    </div>
                    <div className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">Web</span>
                          <span className="text-neutral-50">54</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[84%] rounded-full bg-violet-500 h-full" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">Airflow</span>
                          <span className="text-neutral-50">38</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[62%] rounded-full bg-violet-400 h-full" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">dbt</span>
                          <span className="text-neutral-50">29</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[48%] rounded-full bg-violet-300 h-full" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm leading-5 flex justify-between items-center">
                          <span className="text-[#a1a1a1]">Spark</span>
                          <span className="text-neutral-50">21</span>
                        </div>
                        <div className="rounded-full bg-neutral-800 h-2 overflow-hidden">
                          <div className="w-[36%] rounded-full bg-violet-200 h-full" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="fixed flex right-6 bottom-6 flex-col gap-3">
                <div className="shadow-[0_18px_50px_oklch(0_0_0/.35)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid px-4 py-3">
                  <div className="font-medium text-sm leading-5">
                    Incident acknowledged
                  </div>
                  <div className="text-[#a1a1a1] text-xs leading-4">
                    Toast notifications appear here with smooth fade and slide.
                  </div>
                </div>
              </div>
              <div className="pointer-events-none hidden absolute inset-0">
                <div className="rounded-2xl bg-red-500/10 text-red-200 border-red-500/30 border-1 border-solid px-4 py-3">
                  Unable to connect to backend
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
