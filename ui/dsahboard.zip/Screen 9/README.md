# Screen 9

This is a code bundle for Screen 9. It's based on default Vite project. The original design is available at https://app.flowstep.ai/file?activeFileId=dc42e551-ca39-4e4d-8e28-ee30cd6d8749.

## Running the code

Run `npm i` and `npm run setup` to install the dependencies.

Run `npm run dev` to start the development server.
