import { useEffect } from "react";
import {
  AlertCircle,
  BellRing,
  BookOpen,
  CloudCog,
  Database,
  FileCode2,
  LayoutDashboard,
  MessageSquare,
  Plug,
  Plus,
  RefreshCw,
  RotateCcw,
  SlidersHorizontal,
  Snowflake,
  Sparkles,
  Stethoscope,
  WifiOff,
  Workflow,
  Zap,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[956px] bg-neutral-950 text-neutral-50 flex w-full">
          <aside className="bg-neutral-900/70 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col justify-between w-57.5">
            <div className="space-y-8">
              <div className="flex items-center gap-3">
                <div className="size-10 shadow-[0_0_0_1px_oklch(1_0_0_/_10%)] rounded-xl bg-neutral-200 text-neutral-900 flex justify-center items-center">
                  <Plug className="size-5" />
                </div>
                <div>
                  <div className="leading-none font-semibold text-lg leading-7">
                    Sentinel
                  </div>
                  <div className="text-[#a1a1a1] text-xs leading-4 mt-1">
                    Integrations
                  </div>
                </div>
              </div>
              <nav className="flex flex-col gap-2">
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <LayoutDashboard className="size-4" />
                  <span>Dashboard</span>
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <AlertCircle className="size-4" />
                  <span>Incidents</span>
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Zap className="size-4" />
                  <span>Pipelines</span>
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Stethoscope className="size-4" />
                  <span>Diagnose</span>
                </button>
                <button className="shadow-sm font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Plug className="size-4" />
                  <span>Integrations</span>
                </button>
              </nav>
            </div>
            <div className="rounded-2xl bg-neutral-800/40 border-white/10 border-1 border-solid p-4">
              <div className="flex items-center gap-3">
                <div className="size-9 font-semibold rounded-full bg-neutral-200 text-neutral-900 text-sm leading-5 flex justify-center items-center">
                  AM
                </div>
                <div>
                  <div className="font-medium text-sm leading-5">
                    Alex Morgan
                  </div>
                  <div className="text-[#a1a1a1] text-xs leading-4">
                    On call
                  </div>
                </div>
              </div>
            </div>
          </aside>
          <main className="p-8 flex-1">
            <div className="max-w-[1140px] flex mx-auto flex-col gap-6 w-full">
              <div className="flex justify-between items-start gap-6">
                <div>
                  <h1 className="leading-tight font-semibold text-3xl leading-9 tracking-tight">
                    Integrations
                  </h1>
                  <p className="text-[#a1a1a1] text-sm leading-5 mt-2">
                    Connect your data platforms and alerting tools
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <button className="inline-flex shadow-sm font-medium rounded-xl bg-neutral-900 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                    <RefreshCw className="size-4 text-[#a1a1a1]" />
                    <span>Refresh</span>
                  </button>
                  <button className="inline-flex shadow-sm font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 px-4 py-2.5 items-center gap-2">
                    <Plug className="size-4" />
                    <span>Add integration</span>
                  </button>
                </div>
              </div>
              <div className="shadow-sm rounded-2xl bg-red-500/10 text-red-300 border-red-500/30 border-1 border-solid p-4">
                <div className="flex justify-between items-center gap-4">
                  <div className="flex items-center gap-3">
                    <WifiOff className="size-5" />
                    <div>
                      <div className="font-medium">
                        Unable to connect to backend
                      </div>
                      <div className="text-red-200/80 text-sm leading-5">
                        Data may be outdated. Check your connection and try
                        again.
                      </div>
                    </div>
                  </div>
                  <button className="inline-flex font-medium rounded-xl bg-neutral-950/20 text-red-300 text-sm leading-5 border-red-500/30 border-1 border-solid px-4 py-2 items-center gap-2">
                    <RotateCcw className="size-4" />
                    <span>Retry</span>
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <Workflow className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          Airflow
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-emerald-500/15 text-emerald-400 text-xs leading-4 px-3 py-1">
                          Connected
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2 items-center gap-2">
                      <SlidersHorizontal className="size-4" />
                      <span>Configure</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced 2 minutes ago
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <FileCode2 className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          dbt
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-emerald-500/15 text-emerald-400 text-xs leading-4 px-3 py-1">
                          Connected
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2 items-center gap-2">
                      <SlidersHorizontal className="size-4" />
                      <span>Configure</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced 14 minutes ago
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <Sparkles className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          Spark
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-amber-500/15 text-amber-400 text-xs leading-4 px-3 py-1">
                          Not connected
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 px-3 py-2 items-center gap-2">
                      <Plus className="size-4" />
                      <span>Connect</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced —
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <Database className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          Databricks
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-emerald-500/15 text-emerald-400 text-xs leading-4 px-3 py-1">
                          Connected
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2 items-center gap-2">
                      <SlidersHorizontal className="size-4" />
                      <span>Configure</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced 1 hour ago
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <Snowflake className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          Snowflake
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-red-500/15 text-red-300 text-xs leading-4 px-3 py-1">
                          Error
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2 items-center gap-2">
                      <SlidersHorizontal className="size-4" />
                      <span>Configure</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced 3 hours ago
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <CloudCog className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          ADF
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-amber-500/15 text-amber-400 text-xs leading-4 px-3 py-1">
                          Not connected
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 px-3 py-2 items-center gap-2">
                      <Plus className="size-4" />
                      <span>Connect</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced —
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <MessageSquare className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          Slack
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-emerald-500/15 text-emerald-400 text-xs leading-4 px-3 py-1">
                          Connected
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2 items-center gap-2">
                      <SlidersHorizontal className="size-4" />
                      <span>Configure</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced 8 minutes ago
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-3">
                      <div className="size-11 rounded-2xl bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                        <BellRing className="size-5" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-lg leading-7">
                          PagerDuty
                        </div>
                        <div className="inline-flex font-medium rounded-full bg-emerald-500/15 text-emerald-400 text-xs leading-4 px-3 py-1">
                          Connected
                        </div>
                      </div>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2 items-center gap-2">
                      <SlidersHorizontal className="size-4" />
                      <span>Configure</span>
                    </button>
                  </div>
                  <div className="text-[#a1a1a1] text-sm leading-5 mt-5">
                    Last synced 22 minutes ago
                  </div>
                </div>
              </div>
              <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                <div className="flex mb-4 justify-between items-center gap-4">
                  <div>
                    <div className="font-semibold text-lg leading-7">
                      Loading integrations
                    </div>
                    <div className="text-[#a1a1a1] text-sm leading-5">
                      Pulsing placeholders while we fetch connection status
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="animate-pulse rounded-2xl bg-neutral-800/60 h-32" />
                  <div className="animate-pulse rounded-2xl bg-neutral-800/60 h-32" />
                  <div className="animate-pulse rounded-2xl bg-neutral-800/60 h-32" />
                </div>
              </div>
              <div className="shadow-sm text-center rounded-3xl bg-neutral-900/40 border-white/10 border-1 border-dashed px-8 py-16">
                <div className="max-w-md flex mx-auto flex-col items-center gap-3">
                  <div className="size-12 rounded-full bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                    <Plug className="size-5" />
                  </div>
                  <h3 className="font-semibold text-lg leading-7">
                    No integrations configured — connect a platform to start
                    monitoring
                  </h3>
                  <p className="text-[#a1a1a1] text-sm leading-6">
                    Add your first data source or alerting tool to begin syncing
                    health and incident signals.
                  </p>
                  <div className="flex pt-2 items-center gap-3">
                    <button className="inline-flex shadow-sm font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 px-4 py-2.5 items-center gap-2">
                      <Plus className="size-4" />
                      <span>Connect platform</span>
                    </button>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                      <BookOpen className="size-4" />
                      <span>View setup guide</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
