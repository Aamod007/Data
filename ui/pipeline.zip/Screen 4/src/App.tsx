import { useEffect } from "react";
import {
  AlertCircle,
  LayoutDashboard,
  Plus,
  RefreshCw,
  RotateCcw,
  SearchX,
  Stethoscope,
  WifiOff,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 flex w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <aside className="shrink-0 min-h-[956px] bg-neutral-900 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col gap-8 w-64">
          <div className="flex px-1 items-center gap-3">
            <div className="size-10 shadow-[0_0_0_1px_rgba(255,255,255,0.06)] rounded-xl bg-neutral-200 text-neutral-900 flex justify-center items-center">
              <Zap className="size-5" />
            </div>
            <div className="leading-none flex flex-col">
              <span className="font-semibold text-neutral-50 text-base leading-6 tracking-tight">
                FlowOps
              </span>
              <span className="text-neutral-50/60 text-xs leading-4">
                Incident intelligence
              </span>
            </div>
          </div>
          <nav className="flex flex-col gap-1">
            <a className="transition-colors rounded-xl text-neutral-50/70 text-sm leading-5 flex px-3 py-2.5 items-center gap-3">
              <LayoutDashboard className="size-4" />
              <span>Dashboard</span>
            </a>
            <a className="transition-colors rounded-xl text-neutral-50/70 text-sm leading-5 flex px-3 py-2.5 items-center gap-3">
              <AlertCircle className="size-4" />
              <span>Incidents</span>
            </a>
            <a className="font-medium shadow-[0_0_0_1px_rgba(255,255,255,0.04)] rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 flex px-3 py-2.5 items-center gap-3">
              <Zap className="size-4" />
              <span>Pipelines</span>
            </a>
            <a className="transition-colors rounded-xl text-neutral-50/70 text-sm leading-5 flex px-3 py-2.5 items-center gap-3">
              <Stethoscope className="size-4" />
              <span>Diagnose</span>
            </a>
          </nav>
          <div className="rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid flex mt-auto p-4 items-center gap-3">
            <div className="size-9 font-medium rounded-full bg-neutral-800 text-neutral-50 text-sm leading-5 flex justify-center items-center">
              DM
            </div>
            <div className="min-w-0 flex flex-col">
              <span className="truncate font-medium text-neutral-50 text-sm leading-5">
                Daniel Morgan
              </span>
              <span className="truncate text-[#a1a1a1] text-xs leading-4">
                Data Engineer
              </span>
            </div>
          </div>
        </aside>
        <main className="min-h-[956px] p-12 flex-1 overflow-auto">
          <div className="flex flex-col gap-8">
            <div className="flex justify-between items-start gap-6">
              <div className="flex flex-col gap-1">
                <h1 className="font-semibold text-neutral-50 text-3xl leading-9 tracking-tight">
                  Pipelines
                </h1>
                <p className="text-[#a1a1a1] text-sm leading-5">
                  Monitor run health across all data platforms
                </p>
              </div>
              <Button
                variant="outline"
                className="rounded-xl bg-neutral-900 text-neutral-50 border-white/10 border-0 border-solid gap-2"
              >
                <RefreshCw className="size-4" />
                Refresh
              </Button>
            </div>
            <div className="border-[oklch(0.704_0.191_22.216_/_0.35)] bg-[oklch(0.704_0.191_22.216_/_0.12)] shadow-[0_1px_0_rgba(255,255,255,0.03)_inset] rounded-2xl border-black/1 border-1 border-solid flex p-4 items-center gap-4">
              <WifiOff className="size-5 shrink-0 text-[#ff6467]" />
              <div className="flex flex-col flex-1 gap-0.5">
                <span className="font-semibold text-neutral-50 text-sm leading-5">
                  Unable to connect to backend
                </span>
                <span className="text-[#a1a1a1] text-xs leading-4">
                  We couldn't reach the pipelines service. Check your connection
                  and try again.
                </span>
              </div>
              <Button className="rounded-xl bg-[#ff6467] text-white gap-2">
                <RotateCcw className="size-4" />
                Retry
              </Button>
            </div>
            <Card className="shadow-[0_10px_30px_rgba(0,0,0,0.25)] rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-0 gap-0 overflow-hidden">
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] font-medium uppercase bg-neutral-900 text-[#a1a1a1] text-xs leading-4 tracking-[2.88px] border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid px-6 py-3 items-center gap-4">
                <span>Name</span>
                <span>Platform</span>
                <span className="text-right">Runs</span>
                <span className="text-right">Failed</span>
                <span>Failure Rate</span>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  orders_daily_load
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    Airflow
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  1240
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  12
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[3%] bg-[oklch(0.696_0.17_162.48)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    1.0%
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors bg-neutral-800/20 px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  customer_dbt_models
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    dbt
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  860
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  58
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[7%] bg-[oklch(0.696_0.17_162.48)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    6.7%
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  events_spark_stream
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    Spark
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  2100
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  315
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[15%] bg-[oklch(0.769_0.188_70.08)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    15.0%
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors bg-neutral-800/20 px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  ml_feature_pipeline
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    Databricks
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  540
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  97
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[18%] bg-[oklch(0.769_0.188_70.08)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    18.0%
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  finance_warehouse_sync
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    Snowflake
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  430
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  168
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[39%] bg-[oklch(0.704_0.191_22.216)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    39.1%
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors bg-neutral-800/20 px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  marketing_adf_ingest
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    ADF
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  720
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  31
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[4%] bg-[oklch(0.696_0.17_162.48)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    4.3%
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  inventory_batch_etl
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    Airflow
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  990
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  123
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[12%] bg-[oklch(0.769_0.188_70.08)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    12.4%
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] transition-colors bg-neutral-800/20 px-6 py-4 items-center gap-4">
                <span className="font-semibold text-neutral-50">
                  clickstream_transform
                </span>
                <span>
                  <span className="inline-flex rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 px-2.5 py-1">
                    dbt
                  </span>
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  1580
                </span>
                <span className="text-right text-neutral-50 text-sm leading-5">
                  22
                </span>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-neutral-800 flex-1 h-1.5 overflow-hidden">
                    <div className="w-[2%] bg-[oklch(0.696_0.17_162.48)] rounded-full h-full" />
                  </div>
                  <span className="text-right text-[#a1a1a1] text-xs leading-4 w-10">
                    1.4%
                  </span>
                </div>
              </div>
            </Card>
            <Card className="shadow-[0_10px_30px_rgba(0,0,0,0.25)] rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-0 gap-0 overflow-hidden">
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] font-medium uppercase bg-neutral-900 text-[#a1a1a1] text-xs leading-4 tracking-[2.88px] border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid px-6 py-3 items-center gap-4">
                <span>Name</span>
                <span>Platform</span>
                <span className="text-right">Runs</span>
                <span className="text-right">Failed</span>
                <span>Failure Rate</span>
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] px-6 py-4 items-center gap-4">
                <div className="animate-pulse rounded-full bg-neutral-800 w-40 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 w-16 h-5" />
                <div className="animate-pulse rounded-full bg-neutral-800 justify-self-end w-10 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 justify-self-end w-8 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 w-full h-1.5" />
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] bg-neutral-800/20 px-6 py-4 items-center gap-4">
                <div className="animate-pulse rounded-full bg-neutral-800 w-52 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 w-14 h-5" />
                <div className="animate-pulse rounded-full bg-neutral-800 justify-self-end w-12 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 justify-self-end w-8 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 w-full h-1.5" />
              </div>
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_2fr] px-6 py-4 items-center gap-4">
                <div className="animate-pulse rounded-full bg-neutral-800 w-36 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 w-16 h-5" />
                <div className="animate-pulse rounded-full bg-neutral-800 justify-self-end w-10 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 justify-self-end w-8 h-4" />
                <div className="animate-pulse rounded-full bg-neutral-800 w-full h-1.5" />
              </div>
            </Card>
            <Card className="shadow-[0_10px_30px_rgba(0,0,0,0.25)] rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-12 gap-0">
              <CardContent className="text-center flex p-0 flex-col justify-center items-center gap-4">
                <div className="size-16 rounded-full bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                  <SearchX className="size-8" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="font-semibold text-neutral-50 text-lg leading-7">
                    No pipelines found
                  </span>
                  <span className="text-[#a1a1a1] text-sm leading-5">
                    Connect a data platform to start monitoring pipeline runs
                    here.
                  </span>
                </div>
                <Button
                  variant="outline"
                  className="rounded-xl bg-neutral-900 text-neutral-50 border-white/10 border-0 border-solid gap-2"
                >
                  <Plus className="size-4" />
                  Add pipeline source
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
