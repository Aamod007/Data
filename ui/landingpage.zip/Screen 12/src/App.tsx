import { useEffect } from "react";
import {
  Activity,
  BookOpen,
  Bot,
  Brain,
  Check,
  CreditCard,
  GitBranch,
  Plug,
  Search,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit overflow-hidden h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="relative min-h-[956px] bg-blue-500/18 w-full">
          <div className="max-w-[1140px] flex mx-auto p-6 flex-col w-full">
            <header className="flex justify-between items-center gap-6">
              <div className="flex items-center gap-3">
                <div className="size-10 shadow-[0_0_0_1px_rgba(255,255,255,0.08),0_10px_30px_rgba(0,0,0,0.35)] rounded-full bg-neutral-200 text-neutral-900 flex justify-center items-center">
                  <Sparkles className="size-5" />
                </div>
                <div className="leading-none flex flex-col">
                  <span className="font-semibold text-neutral-50 text-sm leading-5 tracking-tight">
                    Sentinel
                  </span>
                  <span className="text-[#a1a1a1] text-xs leading-4">
                    Incident intelligence
                  </span>
                </div>
              </div>
              <nav className="hidden items-center gap-8">
                <a
                  className="transition-colors text-[#a1a1a1] text-sm leading-5"
                  href="#"
                >
                  Product
                </a>
                <a
                  className="transition-colors text-[#a1a1a1] text-sm leading-5"
                  href="#"
                >
                  Features
                </a>
                <a
                  className="transition-colors text-[#a1a1a1] text-sm leading-5"
                  href="#"
                >
                  Pricing
                </a>
                <a
                  className="transition-colors text-[#a1a1a1] text-sm leading-5"
                  href="#"
                >
                  Docs
                </a>
              </nav>
              <div className="flex items-center gap-4">
                <a
                  className="transition-colors text-[#a1a1a1] text-sm leading-5"
                  href="#"
                >
                  Sign in
                </a>
                <Button className="font-medium rounded-full bg-neutral-200 text-neutral-900 text-sm leading-5 px-5">
                  Get started
                </Button>
              </div>
            </header>
            <section className="text-center flex pt-14 flex-col items-center">
              <div className="inline-flex font-medium shadow-[0_10px_30px_rgba(0,0,0,0.25)] rounded-full bg-neutral-900 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-4 py-2 items-center gap-2">
                <Sparkles className="size-3.5 text-neutral-200" />
                AI-powered incident intelligence
              </div>
              <h1 className="max-w-4xl text-balance font-semibold text-neutral-50 text-5xl leading-12 tracking-tight mt-6">
                Diagnose pipeline and service incidents in minutes, not hours.
              </h1>
              <p className="max-w-3xl text-pretty text-[#a1a1a1] text-base leading-7 mt-6">
                Sentinel turns noisy logs, recurring failures, and platform
                signals into clear root causes, recommended fixes, and learning
                loops your team can trust.
              </p>
              <div className="flex mt-8 flex-wrap justify-center items-center gap-4">
                <Button className="font-semibold rounded-full bg-neutral-200 text-neutral-900 text-sm leading-5 p-6">
                  Start free
                </Button>
                <a
                  className="transition-colors font-medium text-neutral-50 text-sm leading-5"
                  href="#"
                >
                  View live demo
                </a>
              </div>
              <div className="text-left flex mt-8 items-center gap-4">
                <div className="-space-x-2 flex">
                  <div className="size-9 bg-[linear-gradient(135deg,oklch(0.488_0.243_264.376),oklch(0.696_0.17_162.48))] rounded-full border-neutral-950 border-1 border-solid" />
                  <div className="size-9 bg-[linear-gradient(135deg,oklch(0.627_0.265_303.9),oklch(0.488_0.243_264.376))] rounded-full border-neutral-950 border-1 border-solid" />
                  <div className="size-9 bg-[linear-gradient(135deg,oklch(0.696_0.17_162.48),oklch(0.769_0.188_70.08))] rounded-full border-neutral-950 border-1 border-solid" />
                  <div className="size-9 bg-[linear-gradient(135deg,oklch(0.645_0.246_16.439),oklch(0.627_0.265_303.9))] rounded-full border-neutral-950 border-1 border-solid" />
                </div>
                <div className="text-[#a1a1a1] text-sm leading-5">
                  <span className="font-semibold text-neutral-50">
                    Trusted by 1000+ engineers
                  </span>
                  at modern data and platform teams
                </div>
              </div>
            </section>
            <section className="relative flex mt-14 pb-16 justify-center">
              <div className="relative max-w-[760px] w-full">
                <Card className="relative backdrop-blur-sm shadow-[0_30px_80px_rgba(0,0,0,0.45)] rounded-3xl bg-neutral-900/95 border-white/10 border-0 border-solid mx-auto p-6 w-full overflow-hidden">
                  <CardHeader className="p-0 gap-2">
                    <div className="flex justify-between items-center">
                      <div className="font-medium text-[#a1a1a1] text-sm leading-5">
                        Dashboard preview
                      </div>
                      <div className="text-[#a1a1a1] text-sm leading-5">
                        Last 30 days
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="grid mt-5 p-0 gap-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Card className="rounded-2xl bg-neutral-950/40 border-white/10 border-0 border-solid p-4 gap-3">
                        <CardHeader className="p-0 gap-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[#a1a1a1] text-xs leading-4">
                              Avg confidence
                            </span>
                            <span className="text-[#a1a1a1] text-xs leading-4">
                              <TrendingUp className="inline size-3.5" />
                            </span>
                          </div>
                        </CardHeader>
                        <CardContent className="p-0 gap-2">
                          <div className="font-semibold text-neutral-50 text-4xl leading-10 tracking-tight">
                            92%
                          </div>
                          <div className="rounded-xl bg-blue-600/18 mt-4 p-3 h-12">
                            <svg className="w-full h-full" viewBox="0 0 180 40">
                              <path
                                d="M0 30 C20 28, 28 34, 40 26 S70 18, 84 22 S110 12, 126 16 S150 10, 180 8"
                                fill="none"
                                stroke="oklch(0.488_0.243_264.376)"
                                strokeLinecap="round"
                                strokeWidth="3"
                              />
                            </svg>
                          </div>
                        </CardContent>
                      </Card>
                      <Card className="rounded-2xl bg-neutral-950/40 border-white/10 border-0 border-solid p-4 gap-3">
                        <CardHeader className="p-0 gap-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[#a1a1a1] text-xs leading-4">
                              AI status
                            </span>
                            <Bot className="size-4 text-neutral-200" />
                          </div>
                        </CardHeader>
                        <CardContent className="p-0 gap-2">
                          <div className="inline-flex font-medium rounded-full bg-neutral-800 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1 items-center gap-2">
                            <span className="size-2 rounded-full bg-emerald-400" />
                            AI enabled
                          </div>
                          <p className="text-[#a1a1a1] text-sm leading-6 mt-3">
                            Rules plus model-assisted diagnosis
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                    <Card className="rounded-2xl bg-neutral-950/40 border-white/10 border-0 border-solid p-4">
                      <CardHeader className="p-0 gap-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[#a1a1a1] text-xs leading-4">
                            Incidents over time
                          </span>
                          <span className="text-[#a1a1a1] text-xs leading-4">
                            Last 30 days
                          </span>
                        </div>
                      </CardHeader>
                      <CardContent className="p-0 gap-2">
                        <div className="rounded-2xl bg-blue-600/12 mt-3 p-4 h-40">
                          <svg className="w-full h-full" viewBox="0 0 520 120">
                            <path
                              d="M0 92 C40 88, 52 74, 84 78 S132 62, 160 66 S212 48, 244 52 S300 34, 332 38 S392 24, 428 28 S476 18, 520 20"
                              fill="none"
                              stroke="oklch(0.488_0.243_264.376)"
                              strokeLinecap="round"
                              strokeWidth="4"
                            />
                          </svg>
                        </div>
                      </CardContent>
                    </Card>
                    <div className="grid grid-cols-2 gap-4">
                      <Card className="rounded-2xl bg-neutral-950/40 border-white/10 border-0 border-solid p-4">
                        <CardHeader className="p-0 gap-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[#a1a1a1] text-xs leading-4">
                              By root cause
                            </span>
                            <Activity className="size-4 text-neutral-200" />
                          </div>
                        </CardHeader>
                        <CardContent className="p-0 gap-3">
                          <div className="space-y-3">
                            <div>
                              <div className="text-[#a1a1a1] text-xs leading-4 flex mb-1 justify-between">
                                <span>Timeouts</span>
                                <span>42%</span>
                              </div>
                              <div className="rounded-full bg-neutral-800 h-2">
                                <div className="w-[42%] rounded-full bg-neutral-200 h-2" />
                              </div>
                            </div>
                            <div>
                              <div className="text-[#a1a1a1] text-xs leading-4 flex mb-1 justify-between">
                                <span>Schema drift</span>
                                <span>28%</span>
                              </div>
                              <div className="rounded-full bg-neutral-800 h-2">
                                <div className="w-[28%] bg-[oklch(0.627_0.265_303.9)] rounded-full h-2" />
                              </div>
                            </div>
                            <div>
                              <div className="text-[#a1a1a1] text-xs leading-4 flex mb-1 justify-between">
                                <span>Capacity</span>
                                <span>18%</span>
                              </div>
                              <div className="rounded-full bg-neutral-800 h-2">
                                <div className="w-[18%] rounded-full bg-[#a1a1a1] h-2" />
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card className="rounded-2xl bg-neutral-950/40 border-white/10 border-0 border-solid p-4">
                        <CardHeader className="p-0 gap-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[#a1a1a1] text-xs leading-4">
                              By platform
                            </span>
                            <Zap className="size-4 text-neutral-200" />
                          </div>
                        </CardHeader>
                        <CardContent className="p-0 gap-3">
                          <div className="space-y-3">
                            <div>
                              <div className="text-[#a1a1a1] text-xs leading-4 flex mb-1 justify-between">
                                <span>Airflow</span>
                                <span>36%</span>
                              </div>
                              <div className="rounded-full bg-neutral-800 h-2">
                                <div className="w-[36%] rounded-full bg-neutral-200 h-2" />
                              </div>
                            </div>
                            <div>
                              <div className="text-[#a1a1a1] text-xs leading-4 flex mb-1 justify-between">
                                <span>dbt</span>
                                <span>24%</span>
                              </div>
                              <div className="rounded-full bg-neutral-800 h-2">
                                <div className="w-[24%] bg-[oklch(0.627_0.265_303.9)] rounded-full h-2" />
                              </div>
                            </div>
                            <div>
                              <div className="text-[#a1a1a1] text-xs leading-4 flex mb-1 justify-between">
                                <span>Spark</span>
                                <span>18%</span>
                              </div>
                              <div className="rounded-full bg-neutral-800 h-2">
                                <div className="w-[18%] rounded-full bg-[#a1a1a1] h-2" />
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                </Card>
                <div className="backdrop-blur-sm shadow-[0_20px_60px_rgba(0,0,0,0.45)] rounded-2xl bg-neutral-900/95 border-white/10 border-1 border-solid absolute -left-8 top-10 p-4 w-62.5">
                  <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                    <span>Incident / INC-2048</span>
                    <span className="font-medium rounded-full bg-emerald-500/15 text-emerald-300 text-[11px] px-2 py-1">
                      Live
                    </span>
                  </div>
                  <div className="font-medium text-neutral-50 text-sm leading-5 mt-3">
                    Checkout latency spike causing payment failures
                  </div>
                  <div className="rounded-full bg-neutral-800 mt-3 h-2">
                    <div className="w-[84%] rounded-full bg-neutral-200 h-2" />
                  </div>
                  <div className="text-[#a1a1a1] text-xs leading-4 flex mt-3 justify-between items-center">
                    <span>Confidence</span>
                    <span className="font-medium text-neutral-50">94%</span>
                  </div>
                </div>
                <div className="backdrop-blur-sm shadow-[0_20px_60px_rgba(0,0,0,0.45)] rounded-2xl bg-neutral-900/95 border-white/10 border-1 border-solid absolute -right-6 top-6 p-4 w-55">
                  <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                    <span>AI status</span>
                    <Bot className="size-4 text-neutral-200" />
                  </div>
                  <div className="inline-flex font-medium rounded-full bg-neutral-800 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid mt-3 px-3 py-1 items-center gap-2">
                    <span className="size-2 rounded-full bg-emerald-400" />
                    AI enabled
                  </div>
                  <p className="text-[#a1a1a1] text-xs leading-5 mt-3">
                    Rules plus model-assisted diagnosis
                  </p>
                </div>
              </div>
            </section>
            <section className="pb-16">
              <div className="flex justify-between items-end gap-6">
                <div>
                  <div className="inline-flex font-medium rounded-full bg-neutral-900 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-4 py-2 items-center gap-2">
                    <Sparkles className="size-3.5 text-neutral-200" />
                    How it works
                  </div>
                  <h2 className="max-w-3xl font-semibold text-neutral-50 text-3xl leading-9 tracking-tight mt-5">
                    Everything your team needs to move from alert to action.
                  </h2>
                </div>
                <p className="max-w-xl text-[#a1a1a1] text-sm leading-6">
                  Built for incident response, root-cause analysis, and the
                  learning loop that prevents repeat failures.
                </p>
              </div>
              <div className="grid mt-8 gap-4">
                <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5">
                  <CardContent className="flex p-0 items-start gap-4">
                    <div className="size-10 rounded-full bg-neutral-200/10 text-neutral-200 flex justify-center items-center">
                      <Brain className="size-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-50 text-base leading-6">
                        AI diagnosis
                      </h3>
                      <p className="text-[#a1a1a1] text-sm leading-6 mt-2">
                        Turn logs and metrics into plain-English root causes,
                        confidence, and recommended fixes.
                      </p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5">
                  <CardContent className="flex p-0 items-start gap-4">
                    <div className="size-10 rounded-full bg-neutral-200/10 text-neutral-200 flex justify-center items-center">
                      <Search className="size-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-50 text-base leading-6">
                        Evidence linking
                      </h3>
                      <p className="text-[#a1a1a1] text-sm leading-6 mt-2">
                        Highlight the exact log lines and signals that support
                        each diagnosis so engineers can verify fast.
                      </p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5">
                  <CardContent className="flex p-0 items-start gap-4">
                    <div className="size-10 rounded-full bg-neutral-200/10 text-neutral-200 flex justify-center items-center">
                      <GitBranch className="size-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-50 text-base leading-6">
                        Recurring issue detection
                      </h3>
                      <p className="text-[#a1a1a1] text-sm leading-6 mt-2">
                        Spot repeat incidents across pipelines and services
                        before they become chronic outages.
                      </p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5">
                  <CardContent className="flex p-0 items-start gap-4">
                    <div className="size-10 rounded-full bg-neutral-200/10 text-neutral-200 flex justify-center items-center">
                      <BookOpen className="size-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-50 text-base leading-6">
                        Knowledge base loop
                      </h3>
                      <p className="text-[#a1a1a1] text-sm leading-6 mt-2">
                        Capture fixes from resolved incidents and feed them back
                        into future diagnoses automatically.
                      </p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5">
                  <CardContent className="flex p-0 items-start gap-4">
                    <div className="size-10 rounded-full bg-neutral-200/10 text-neutral-200 flex justify-center items-center">
                      <Plug className="size-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-50 text-base leading-6">
                        Easy integrations
                      </h3>
                      <p className="text-[#a1a1a1] text-sm leading-6 mt-2">
                        Connect Airflow, dbt, Spark, Slack, and PagerDuty in
                        minutes with setup guides and test events.
                      </p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5">
                  <CardContent className="flex p-0 items-start gap-4">
                    <div className="size-10 rounded-full bg-neutral-200/10 text-neutral-200 flex justify-center items-center">
                      <ShieldCheck className="size-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-50 text-base leading-6">
                        Safe by default
                      </h3>
                      <p className="text-[#a1a1a1] text-sm leading-6 mt-2">
                        Redaction-aware logs, role-based access, and clear
                        action trails keep incident response secure.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </section>
            <section className="pb-16">
              <Card className="shadow-[0_20px_60px_rgba(0,0,0,0.35)] rounded-3xl bg-neutral-900 border-white/10 border-0 border-solid p-6">
                <CardHeader className="p-0 gap-4">
                  <div className="inline-flex font-medium rounded-full bg-neutral-800 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-4 py-2 items-center gap-2 w-fit">
                    <CreditCard className="size-3.5 text-neutral-200" />
                    Pricing
                  </div>
                  <div className="max-w-3xl">
                    <h2 className="font-semibold text-neutral-50 text-3xl leading-9 tracking-tight">
                      Start free, scale with your incident volume.
                    </h2>
                    <p className="text-[#a1a1a1] text-sm leading-6 mt-3">
                      Use Sentinel to reduce mean time to resolution, improve
                      on-call confidence, and build a durable knowledge base
                      from every incident.
                    </p>
                  </div>
                </CardHeader>
                <CardContent className="mt-6 p-0">
                  <Card className="rounded-3xl bg-neutral-950/50 border-white/10 border-0 border-solid p-6">
                    <CardHeader className="p-0 gap-2">
                      <div className="text-[#a1a1a1] text-sm leading-5">
                        Starter
                      </div>
                      <div className="flex items-end gap-2">
                        <div className="font-semibold text-neutral-50 text-5xl leading-12 tracking-tight">
                          $0
                        </div>
                        <div className="text-[#a1a1a1] text-sm leading-5 pb-1">
                          / month
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="mt-5 p-0 gap-3">
                      <div className="space-y-3 text-[#a1a1a1] text-sm leading-5">
                        <div className="flex items-center gap-2">
                          <Check className="size-4 text-emerald-400" />
                          Unlimited incident summaries
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="size-4 text-emerald-400" />
                          Dashboard, detail, and diagnose views
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="size-4 text-emerald-400" />
                          Knowledge base feedback loop
                        </div>
                      </div>
                      <Button className="font-semibold rounded-full bg-neutral-200 text-neutral-900 text-sm leading-5 mt-6 py-6 w-full">
                        Get started free
                      </Button>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>
            </section>
            <footer className="border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid pt-10 pb-6">
              <div className="grid gap-10">
                <div>
                  <div className="flex items-center gap-3">
                    <div className="size-10 rounded-full bg-neutral-200 text-neutral-900 flex justify-center items-center">
                      <Sparkles className="size-5" />
                    </div>
                    <div className="leading-none flex flex-col">
                      <span className="font-semibold text-neutral-50 text-sm leading-5">
                        Sentinel
                      </span>
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        Incident intelligence for modern data and platform
                        teams.
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="font-semibold text-neutral-50 text-sm leading-5">
                    Product
                  </div>
                  <div className="space-y-3 text-[#a1a1a1] text-sm leading-5 mt-4">
                    <div>Dashboard</div>
                    <div>Incidents</div>
                    <div>Diagnose</div>
                  </div>
                </div>
                <div>
                  <div className="font-semibold text-neutral-50 text-sm leading-5">
                    Resources
                  </div>
                  <div className="space-y-3 text-[#a1a1a1] text-sm leading-5 mt-4">
                    <div>Docs</div>
                    <div>API</div>
                    <div>Status</div>
                  </div>
                </div>
                <div>
                  <div className="font-semibold text-neutral-50 text-sm leading-5">
                    Legal
                  </div>
                  <div className="space-y-3 text-[#a1a1a1] text-sm leading-5 mt-4">
                    <div>Privacy</div>
                    <div>Terms</div>
                    <div>Security</div>
                  </div>
                </div>
              </div>
              <div className="text-[#a1a1a1] text-sm leading-5 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex mt-10 pt-5 flex-col gap-3">
                <div>© 2026 Sentinel</div>
                <div className="flex gap-6">
                  <span>Built for incident response</span>
                  <span>Dark mode first</span>
                </div>
              </div>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}
