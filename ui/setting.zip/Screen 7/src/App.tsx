import { useEffect } from "react";
import {
  AlertCircle,
  Camera,
  Copy,
  LayoutDashboard,
  Plus,
  RefreshCw,
  RotateCcw,
  Save,
  Settings2,
  Stethoscope,
  UserMinus,
  UserPlus,
  WifiOff,
  Zap,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[956px] bg-neutral-950 text-neutral-50 flex w-full">
          <aside className="shrink-0 bg-neutral-900 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex px-4 py-6 flex-col justify-between w-60">
            <div className="space-y-6">
              <div className="flex px-2 items-center gap-3">
                <div className="size-10 shadow-[0_0_0_1px_oklch(1_0_0_/_0.08)] rounded-xl bg-neutral-200 text-neutral-900 flex justify-center items-center">
                  <Settings2 className="size-5" />
                </div>
                <div>
                  <div className="font-semibold text-lg leading-7">
                    Sentinel
                  </div>
                  <div className="text-[#a1a1a1] text-xs leading-4 mt-1">
                    Incident operations
                  </div>
                </div>
              </div>
              <nav className="flex flex-col gap-2">
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <LayoutDashboard className="size-4" />
                  <span>Dashboard</span>
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <AlertCircle className="size-4" />
                  <span>Incidents</span>
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Zap className="size-4" />
                  <span>Pipelines</span>
                </button>
                <button className="transition-colors font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Stethoscope className="size-4" />
                  <span>Diagnose</span>
                </button>
                <button className="shadow-sm font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 flex px-4 py-3 items-center gap-3">
                  <Settings2 className="size-4" />
                  <span>Settings</span>
                </button>
              </nav>
            </div>
            <div className="rounded-2xl bg-neutral-800/40 border-white/10 border-1 border-solid p-4">
              <div className="flex items-center gap-3">
                <div className="size-9 font-semibold rounded-full bg-neutral-800 text-neutral-50 text-sm leading-5 flex justify-center items-center">
                  AM
                </div>
                <div>
                  <div className="font-medium text-sm leading-5">
                    Alex Morgan
                  </div>
                  <div className="text-[#a1a1a1] text-xs leading-4">
                    On call
                  </div>
                </div>
              </div>
            </div>
          </aside>
          <main className="px-8 py-6 flex-1">
            <div className="flex mb-6 justify-between items-start gap-6">
              <div>
                <h1 className="font-semibold text-3xl leading-9 tracking-tight">
                  Settings
                </h1>
                <p className="text-[#a1a1a1] text-sm leading-5 mt-2">
                  Manage your account, team, and notification preferences
                </p>
              </div>
              <button className="inline-flex shadow-sm font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                <RefreshCw className="size-4" />
                Refresh
              </button>
            </div>
            <div className="shadow-sm rounded-2xl bg-[#ff6467]/10 text-[#ff6467] border-[#ff6467]/40 border-1 border-solid mb-6 p-4">
              <div className="flex justify-between items-center gap-4">
                <div className="flex items-center gap-3">
                  <WifiOff className="size-5" />
                  <div>
                    <div className="font-medium">
                      Unable to connect to backend
                    </div>
                    <div className="text-[#ff6467]/80 text-sm leading-5">
                      Data may be outdated. Check your connection and try again.
                    </div>
                  </div>
                </div>
                <button className="inline-flex font-medium rounded-xl bg-[#ff6467] text-white text-sm leading-5 px-4 py-2 items-center gap-2">
                  <RotateCcw className="size-4" />
                  Retry
                </button>
              </div>
            </div>
            <div className="space-y-6">
              <section className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                <div className="flex justify-between items-start gap-6">
                  <div>
                    <h2 className="font-semibold text-lg leading-7">Profile</h2>
                    <p className="text-[#a1a1a1] text-sm leading-5 mt-1">
                      Update your personal information and role.
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="size-14 font-semibold rounded-full bg-neutral-800 text-neutral-50 text-lg leading-7 flex justify-center items-center">
                      AM
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                      <Camera className="size-4" />
                      Change avatar
                    </button>
                  </div>
                </div>
                <div className="grid mt-6 gap-4">
                  <div className="grid gap-2">
                    <label className="font-medium text-sm leading-5">
                      Name
                    </label>
                    <input
                      className="outline-none rounded-xl bg-neutral-950 text-neutral-50 text-sm leading-5 border-white/15 border-1 border-solid px-4 h-11"
                      value="Alex Morgan"
                      readOnly={true}
                    />
                  </div>
                  <div className="grid gap-2">
                    <label className="font-medium text-sm leading-5">
                      Email
                    </label>
                    <input
                      className="outline-none rounded-xl bg-neutral-950 text-neutral-50 text-sm leading-5 border-white/15 border-1 border-solid px-4 h-11"
                      value="alex.morgan@sentinel.io"
                      readOnly={true}
                    />
                  </div>
                  <div className="grid gap-2">
                    <label className="font-medium text-sm leading-5">
                      Role
                    </label>
                    <input
                      className="outline-none rounded-xl bg-neutral-950 text-neutral-50 text-sm leading-5 border-white/15 border-1 border-solid px-4 h-11"
                      value="SRE Team Lead"
                      readOnly={true}
                    />
                  </div>
                </div>
              </section>
              <section className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                <div>
                  <h2 className="font-semibold text-lg leading-7">
                    Notifications
                  </h2>
                  <p className="text-[#a1a1a1] text-sm leading-5 mt-1">
                    Choose how you want to be alerted about incidents.
                  </p>
                </div>
                <div className="space-y-3 mt-6">
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div>
                      <div className="font-medium text-sm leading-5">
                        New incidents
                      </div>
                      <div className="text-[#a1a1a1] text-sm leading-5">
                        Email and Slack alerts when a new incident is detected.
                      </div>
                    </div>
                    <div className="rounded-full bg-neutral-200/90 flex p-1 items-center w-12 h-7">
                      <div className="size-5 shadow-sm rounded-full bg-neutral-900 ml-auto" />
                    </div>
                  </div>
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div>
                      <div className="font-medium text-sm leading-5">
                        Resolutions
                      </div>
                      <div className="text-[#a1a1a1] text-sm leading-5">
                        Notify when incidents are resolved or closed.
                      </div>
                    </div>
                    <div className="rounded-full bg-neutral-800 flex p-1 items-center w-12 h-7">
                      <div className="size-5 shadow-sm rounded-full bg-[#a1a1a1]" />
                    </div>
                  </div>
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div>
                      <div className="font-medium text-sm leading-5">
                        Recurring issues
                      </div>
                      <div className="text-[#a1a1a1] text-sm leading-5">
                        Escalate repeated incidents to the team channel.
                      </div>
                    </div>
                    <div className="rounded-full bg-neutral-200/90 flex p-1 items-center w-12 h-7">
                      <div className="size-5 shadow-sm rounded-full bg-neutral-900 ml-auto" />
                    </div>
                  </div>
                </div>
              </section>
              <section className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                <div className="flex justify-between items-start gap-6">
                  <div>
                    <h2 className="font-semibold text-lg leading-7">
                      Team Members
                    </h2>
                    <p className="text-[#a1a1a1] text-sm leading-5 mt-1">
                      Manage access and invite new collaborators.
                    </p>
                  </div>
                  <button className="inline-flex shadow-sm font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 px-4 py-2.5 items-center gap-2">
                    <UserPlus className="size-4" />
                    Invite member
                  </button>
                </div>
                <div className="space-y-3 mt-6">
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="size-10 font-semibold rounded-full bg-violet-500/20 text-violet-300 text-sm leading-5 flex justify-center items-center">
                        JD
                      </div>
                      <div>
                        <div className="font-medium text-sm leading-5">
                          Jamie Doe
                        </div>
                        <div className="text-[#a1a1a1] text-xs leading-4">
                          jamie@sentinel.io
                        </div>
                      </div>
                      <span className="font-medium rounded-full bg-neutral-800 text-neutral-50 text-xs leading-4 px-2.5 py-1">
                        Admin
                      </span>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                      <UserMinus className="size-4" />
                      Remove
                    </button>
                  </div>
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="size-10 font-semibold rounded-full bg-cyan-500/20 text-cyan-300 text-sm leading-5 flex justify-center items-center">
                        SR
                      </div>
                      <div>
                        <div className="font-medium text-sm leading-5">
                          Sam Rivera
                        </div>
                        <div className="text-[#a1a1a1] text-xs leading-4">
                          sam@sentinel.io
                        </div>
                      </div>
                      <span className="font-medium rounded-full bg-neutral-800 text-neutral-50 text-xs leading-4 px-2.5 py-1">
                        Editor
                      </span>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                      <UserMinus className="size-4" />
                      Remove
                    </button>
                  </div>
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="size-10 font-semibold rounded-full bg-emerald-500/20 text-emerald-300 text-sm leading-5 flex justify-center items-center">
                        KP
                      </div>
                      <div>
                        <div className="font-medium text-sm leading-5">
                          Kira Patel
                        </div>
                        <div className="text-[#a1a1a1] text-xs leading-4">
                          kira@sentinel.io
                        </div>
                      </div>
                      <span className="font-medium rounded-full bg-neutral-800 text-neutral-50 text-xs leading-4 px-2.5 py-1">
                        Viewer
                      </span>
                    </div>
                    <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                      <UserPlus className="size-4" />
                      Invite
                    </button>
                  </div>
                </div>
              </section>
              <section className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-6">
                <div className="flex justify-between items-start gap-6">
                  <div>
                    <h2 className="font-semibold text-lg leading-7">
                      API Keys
                    </h2>
                    <p className="text-[#a1a1a1] text-sm leading-5 mt-1">
                      Use keys to connect external tools and automations.
                    </p>
                  </div>
                  <button className="inline-flex shadow-sm font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 px-4 py-2.5 items-center gap-2">
                    <Plus className="size-4" />
                    Create key
                  </button>
                </div>
                <div className="space-y-3 mt-6">
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div>
                      <div className="font-medium text-sm leading-5">
                        Production key
                      </div>
                      <div className="font-mono text-[#a1a1a1] text-sm leading-5 mt-1">
                        sk_live_••••••••••••••••••••••••
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                        <Copy className="size-4" />
                        Copy
                      </button>
                      <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                        <RotateCcw className="size-4" />
                        Regenerate
                      </button>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 justify-between items-center">
                    <div>
                      <div className="font-medium text-sm leading-5">
                        Staging key
                      </div>
                      <div className="font-mono text-[#a1a1a1] text-sm leading-5 mt-1">
                        sk_test_••••••••••••••••••••••••
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                        <Copy className="size-4" />
                        Copy
                      </button>
                      <button className="inline-flex font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2.5 items-center gap-2">
                        <RotateCcw className="size-4" />
                        Regenerate
                      </button>
                    </div>
                  </div>
                </div>
              </section>
            </div>
            <div className="border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex mt-8 pt-8 justify-end">
              <button className="inline-flex shadow-lg shadow-black/20 font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 px-5 py-3 items-center gap-2">
                <Save className="size-4" />
                Save changes
              </button>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
