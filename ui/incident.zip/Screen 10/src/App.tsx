import { useEffect } from "react";
import {
  AlertCircle,
  Ban,
  Check,
  CheckCircle2,
  ChevronDown,
  Filter,
  LayoutDashboard,
  Search,
  SearchX,
  Stethoscope,
  WifiOff,
  Zap,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[956px] bg-neutral-950 text-neutral-50 flex w-full">
          <aside className="bg-neutral-900/40 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col justify-between w-65">
            <div className="flex flex-col gap-8">
              <div className="flex items-center gap-3">
                <div className="size-11 shadow-[0_0_0_1px_oklch(1_0_0/_10%)] rounded-2xl bg-neutral-200 text-neutral-900 flex justify-center items-center">
                  <AlertCircle className="size-5" />
                </div>
                <div className="flex flex-col">
                  <span className="leading-none font-semibold text-neutral-50 text-lg leading-7">
                    Sentinel
                  </span>
                  <span className="text-[#a1a1a1] text-xs leading-4">
                    Incident intelligence
                  </span>
                </div>
              </div>
              <nav className="flex flex-col gap-2">
                <button className="border-transparent shadow-sm font-medium rounded-xl bg-neutral-800 text-neutral-50 text-sm leading-5 border-black/1 border-1 border-solid flex px-4 py-3 items-center gap-3">
                  <LayoutDashboard className="size-4 text-[#a1a1a1]" />
                  <span>Dashboard</span>
                </button>
                <button className="font-medium shadow-[0_0_0_1px_oklch(0.556_0_0/_20%)] rounded-xl bg-neutral-200/10 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3">
                  <AlertCircle className="size-4 text-neutral-200" />
                  <span>Incidents</span>
                </button>
                <button className="border-transparent font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 border-black/1 border-1 border-solid flex px-4 py-3 items-center gap-3">
                  <Zap className="size-4" />
                  <span>Pipelines</span>
                </button>
                <button className="border-transparent font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 border-black/1 border-1 border-solid flex px-4 py-3 items-center gap-3">
                  <Stethoscope className="size-4" />
                  <span>Diagnose</span>
                </button>
              </nav>
            </div>
            <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-4">
              <div className="flex items-center gap-3">
                <div className="size-10 font-semibold rounded-full bg-neutral-800 text-neutral-50 text-sm leading-5 flex justify-center items-center">
                  AM
                </div>
                <div className="flex flex-col">
                  <span className="font-medium text-neutral-50 text-sm leading-5">
                    Alex Morgan
                  </span>
                  <span className="text-[#a1a1a1] text-xs leading-4">
                    On call
                  </span>
                </div>
              </div>
            </div>
          </aside>
          <main className="p-8 flex-1">
            <div className="max-w-[840px] flex mx-auto flex-col gap-6">
              <div className="shadow-sm rounded-2xl bg-red-950/30 text-red-200 border-red-500/30 border-1 border-solid p-4">
                <div className="flex justify-between items-center gap-4">
                  <div className="flex items-center gap-3">
                    <WifiOff className="size-4 text-red-300" />
                    <div>
                      <div className="font-medium text-sm leading-5">
                        Unable to connect to backend
                      </div>
                      <div className="text-red-200/70 text-xs leading-4">
                        Data may be outdated. Check your connection and try
                        again.
                      </div>
                    </div>
                  </div>
                  <button className="font-medium rounded-full bg-red-500 text-white text-sm leading-5 px-4 py-2">
                    Retry
                  </button>
                </div>
              </div>
              <header className="flex flex-col gap-6">
                <div className="flex justify-between items-start gap-6">
                  <div className="flex flex-col gap-2">
                    <h1 className="font-semibold text-neutral-50 text-4xl leading-10 tracking-tight">
                      Incidents
                    </h1>
                    <p className="max-w-2xl text-[#a1a1a1] text-sm leading-5">
                      Track, triage, and resolve incident patterns across your
                      systems.
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button className="shadow-sm rounded-full bg-neutral-900 text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2">
                      <Filter className="inline size-4 mr-2" />
                      Filters
                    </button>
                    <button className="shadow-sm rounded-full bg-neutral-900 text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2">
                      <Search className="inline size-4 mr-2" />
                      Search
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-[1fr_auto_auto_auto] gap-3">
                  <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3">
                    <Search className="size-4 text-[#a1a1a1]" />
                    <input
                      className="bg-transparent outline-none text-neutral-50 text-sm leading-5 w-full"
                      placeholder="Search incidents, categories, pipelines"
                    />
                  </div>
                  <button className="shadow-sm rounded-2xl bg-neutral-900 text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-3">
                    Platform
                    <ChevronDown className="inline size-4 ml-2" />
                  </button>
                  <button className="shadow-sm rounded-2xl bg-neutral-900 text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-3">
                    Category
                    <ChevronDown className="inline size-4 ml-2" />
                  </button>
                  <button className="shadow-sm rounded-2xl bg-neutral-900 text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-3">
                    Pipeline
                    <ChevronDown className="inline size-4 ml-2" />
                  </button>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="uppercase text-[#a1a1a1] text-xs leading-4 tracking-[3.84px]">
                    Status
                  </span>
                  <button className="shadow-sm font-medium rounded-full bg-neutral-200 text-neutral-900 text-sm leading-5 px-4 py-2">
                    All
                  </button>
                  <button className="bg-transparent rounded-full text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2">
                    Open
                  </button>
                  <button className="bg-transparent rounded-full text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2">
                    Acknowledged
                  </button>
                  <button className="bg-transparent rounded-full text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2">
                    Resolved
                  </button>
                  <button className="bg-transparent rounded-full text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-2">
                    Ignored
                  </button>
                </div>
              </header>
              <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="size-5 rounded-sm bg-neutral-950 border-white/10 border-1 border-solid flex justify-center items-center">
                    <Check className="size-3 text-neutral-200" />
                  </div>
                  <span className="text-[#a1a1a1] text-sm leading-5">
                    3 selected
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="font-medium rounded-full bg-neutral-800 text-neutral-50 text-sm leading-5 px-4 py-2">
                    Resolve
                  </button>
                  <button className="font-medium rounded-full bg-neutral-800 text-neutral-50 text-sm leading-5 px-4 py-2">
                    Ignore
                  </button>
                </div>
              </div>
              <section className="flex flex-col gap-4">
                <article className="shadow-sm transition-all duration-300 rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-4">
                      <div className="size-5 rounded-sm bg-neutral-950 border-white/10 border-1 border-solid flex mt-1 justify-center items-center">
                        <Check className="size-3 text-neutral-200" />
                      </div>
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-2">
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            12m ago
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            ×4
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Confidence 94%
                          </span>
                        </div>
                        <h2 className="font-semibold text-neutral-50 text-xl leading-7">
                          Checkout latency spike causing payment failures
                        </h2>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium rounded-full bg-emerald-500/15 text-emerald-300 text-xs leading-4 px-3 py-1">
                            Investigating
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            API latency
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Platform: Web
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Pipeline: Payments
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-3">
                      <div className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                        Last seen 2m ago
                      </div>
                      <div className="rounded-full bg-neutral-950 border-white/10 border-1 border-solid flex p-2 items-end gap-1 w-24 h-8">
                        <span className="rounded-full bg-neutral-200/70 w-2 h-2" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-3" />
                        <span className="rounded-full bg-neutral-200 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-3" />
                        <span className="rounded-full bg-neutral-200 w-2 h-5" />
                        <span className="rounded-full bg-neutral-200/70 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200 w-2 h-6" />
                      </div>
                    </div>
                  </div>
                </article>
                <article className="shadow-sm transition-all duration-300 rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-4">
                      <div className="size-5 rounded-sm bg-neutral-950 border-white/10 border-1 border-solid flex mt-1 justify-center items-center">
                        <Check className="size-3 text-neutral-200" />
                      </div>
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-2">
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            28m ago
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            ×12
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Confidence 88%
                          </span>
                        </div>
                        <h2 className="font-semibold text-neutral-50 text-xl leading-7">
                          Schema drift in profile sync jobs
                        </h2>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium rounded-full bg-amber-500/15 text-amber-300 text-xs leading-4 px-3 py-1">
                            Acknowledged
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Data quality
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Platform: dbt
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Pipeline: profile-sync
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-3">
                      <div className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                        Last seen 11m ago
                      </div>
                      <div className="rounded-full bg-neutral-950 border-white/10 border-1 border-solid flex p-2 items-end gap-1 w-24 h-8">
                        <span className="rounded-full bg-neutral-200/70 w-2 h-2" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-3" />
                        <span className="rounded-full bg-neutral-200 w-2 h-5" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200 w-2 h-6" />
                        <span className="rounded-full bg-neutral-200/70 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200 w-2 h-5" />
                      </div>
                    </div>
                  </div>
                </article>
                <article className="shadow-sm transition-all duration-300 rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-4">
                      <div className="size-5 rounded-sm bg-neutral-950 border-white/10 border-1 border-solid flex mt-1 justify-center items-center">
                        <Check className="size-3 text-neutral-200" />
                      </div>
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-2">
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            1h ago
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            ×7
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Confidence 76%
                          </span>
                        </div>
                        <h2 className="font-semibold text-neutral-50 text-xl leading-7">
                          Worker pool exhaustion during peak traffic
                        </h2>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium rounded-full bg-red-500/15 text-red-300 text-xs leading-4 px-3 py-1">
                            Resolved
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Capacity
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Platform: Backend
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Pipeline: checkout-stream
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-3">
                      <div className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                        Last seen 43m ago
                      </div>
                      <div className="rounded-full bg-neutral-950 border-white/10 border-1 border-solid flex p-2 items-end gap-1 w-24 h-8">
                        <span className="rounded-full bg-neutral-200/70 w-2 h-2" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200 w-2 h-3" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-5" />
                        <span className="rounded-full bg-neutral-200 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200/70 w-2 h-6" />
                        <span className="rounded-full bg-neutral-200 w-2 h-5" />
                      </div>
                    </div>
                  </div>
                </article>
                <article className="shadow-sm transition-all duration-300 rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex items-start gap-4">
                      <div className="size-5 rounded-sm bg-neutral-950 border-white/10 border-1 border-solid flex mt-1 justify-center items-center">
                        <Check className="size-3 text-neutral-200" />
                      </div>
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-2">
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            3h ago
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            ×19
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Confidence 91%
                          </span>
                        </div>
                        <h2 className="font-semibold text-neutral-50 text-xl leading-7">
                          External API latency spikes causing cascading retries
                        </h2>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium rounded-full bg-slate-500/15 text-slate-300 text-xs leading-4 px-3 py-1">
                            Ignored
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Reliability
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Platform: AWS
                          </span>
                          <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                            Pipeline: payments-api
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-3">
                      <div className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                        Last seen 2h ago
                      </div>
                      <div className="rounded-full bg-neutral-950 border-white/10 border-1 border-solid flex p-2 items-end gap-1 w-24 h-8">
                        <span className="rounded-full bg-neutral-200/70 w-2 h-2" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-3" />
                        <span className="rounded-full bg-neutral-200 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200/80 w-2 h-5" />
                        <span className="rounded-full bg-neutral-200 w-2 h-4" />
                        <span className="rounded-full bg-neutral-200/70 w-2 h-3" />
                        <span className="rounded-full bg-neutral-200 w-2 h-6" />
                      </div>
                    </div>
                  </div>
                </article>
              </section>
              <section className="shadow-sm rounded-3xl bg-neutral-900 border-white/10 border-1 border-solid p-10">
                <div className="text-center flex flex-col items-center gap-4">
                  <div className="size-14 rounded-full bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                    <SearchX className="size-6" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <h3 className="font-semibold text-neutral-50 text-2xl leading-8">
                      No incidents match this filter
                    </h3>
                    <p className="max-w-md text-[#a1a1a1] text-sm leading-5">
                      Try adjusting status, platform, category, or pipeline
                      filters to broaden the results.
                    </p>
                  </div>
                </div>
              </section>
              <section className="grid gap-4">
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                  <div className="animate-pulse space-y-4">
                    <div className="rounded-full bg-neutral-800 w-28 h-4" />
                    <div className="w-3/4 rounded-full bg-neutral-800 h-6" />
                    <div className="rounded-full bg-neutral-800 w-full h-4" />
                    <div className="w-5/6 rounded-full bg-neutral-800 h-4" />
                  </div>
                </div>
                <div className="shadow-sm rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid p-5">
                  <div className="animate-pulse space-y-4">
                    <div className="rounded-full bg-neutral-800 w-24 h-4" />
                    <div className="w-2/3 rounded-full bg-neutral-800 h-6" />
                    <div className="rounded-full bg-neutral-800 w-full h-4" />
                    <div className="w-4/5 rounded-full bg-neutral-800 h-4" />
                  </div>
                </div>
              </section>
              <div className="fixed flex right-6 bottom-6 flex-col gap-3">
                <div className="shadow-[0_12px_30px_rgba(0,0,0,0.35)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid px-4 py-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="size-4 text-emerald-400" />
                    <div>
                      <div className="font-medium text-neutral-50 text-sm leading-5">
                        Bulk resolve complete
                      </div>
                      <div className="text-[#a1a1a1] text-xs leading-4">
                        3 incidents updated successfully.
                      </div>
                    </div>
                  </div>
                </div>
                <div className="shadow-[0_12px_30px_rgba(0,0,0,0.35)] rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid px-4 py-3">
                  <div className="flex items-center gap-3">
                    <Ban className="size-4 text-amber-400" />
                    <div>
                      <div className="font-medium text-neutral-50 text-sm leading-5">
                        Bulk ignore queued
                      </div>
                      <div className="text-[#a1a1a1] text-xs leading-4">
                        Changes will sync when the backend reconnects.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
