import { useEffect } from "react";
import {
  AlertCircle,
  BookOpen,
  Filter,
  LayoutDashboard,
  RotateCw,
  Search,
  Stethoscope,
  WifiOff,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 flex w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <aside className="shrink-0 min-h-[956px] bg-neutral-900 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col gap-8 w-64">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-neutral-200 text-neutral-900 flex justify-center items-center">
              <BookOpen className="size-5" />
            </div>
            <div className="flex flex-col">
              <span className="font-semibold text-lg leading-6 tracking-tight">
                Sentinel
              </span>
              <span className="text-[#a1a1a1] text-xs leading-4">
                Incident intelligence
              </span>
            </div>
          </div>
          <nav className="flex flex-col gap-2">
            <a className="font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
              <LayoutDashboard className="size-4" />
              <span>Dashboard</span>
            </a>
            <a className="font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
              <AlertCircle className="size-4" />
              <span>Incidents</span>
            </a>
            <a className="font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
              <Zap className="size-4" />
              <span>Pipelines</span>
            </a>
            <a className="font-medium rounded-xl text-[#a1a1a1] text-sm leading-5 flex px-4 py-3 items-center gap-3">
              <Stethoscope className="size-4" />
              <span>Diagnose</span>
            </a>
            <a className="shadow-sm font-medium rounded-xl bg-neutral-200 text-neutral-900 text-sm leading-5 flex px-4 py-3 items-center gap-3">
              <BookOpen className="size-4" />
              <span>Knowledge Base</span>
            </a>
          </nav>
          <div className="rounded-2xl bg-neutral-800 border-white/10 border-1 border-solid flex mt-auto p-4 items-center gap-3">
            <div className="size-10 bg-[oklch(0.488_0.243_264.376)] font-semibold rounded-full text-white text-sm leading-5 flex justify-center items-center">
              AM
            </div>
            <div className="flex flex-col">
              <span className="font-medium text-sm leading-5">Alex Morgan</span>
              <span className="text-[#a1a1a1] text-xs leading-4">On call</span>
            </div>
          </div>
        </aside>
        <main className="flex p-12 flex-col flex-1 gap-6">
          <div className="flex justify-between items-start gap-6">
            <div className="flex flex-col gap-2">
              <h1 className="leading-tight font-semibold text-3xl leading-9 tracking-tight">
                Knowledge Base
              </h1>
              <p className="text-[#a1a1a1] text-sm leading-5">
                Learnings from resolved incidents and feedback
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-neutral-900 text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-2">
                <Search className="size-4" />
                <span>Search knowledge</span>
              </div>
              <div className="rounded-xl bg-neutral-900 text-[#a1a1a1] text-sm leading-5 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-2">
                <Filter className="size-4" />
                <span>Filters</span>
              </div>
            </div>
          </div>
          <div className="border-[oklch(0.704_0.191_22.216/30%)] bg-[oklch(0.704_0.191_22.216/12%)] rounded-2xl border-black/1 border-1 border-solid flex px-5 py-4 items-center gap-3">
            <WifiOff className="size-5 shrink-0 text-[#ff6467]" />
            <div className="flex flex-col">
              <span className="font-medium text-[#ff6467] text-sm leading-5">
                Unable to connect to backend
              </span>
              <span className="text-[#a1a1a1] text-xs leading-4">
                Data may be outdated. Check your connection and try again.
              </span>
            </div>
            <Button
              variant="outline"
              className="border-[oklch(0.704_0.191_22.216/40%)] text-[#ff6467] ml-auto gap-2 h-9"
            >
              <RotateCw className="size-4" />
              Retry
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Button className="rounded-full bg-neutral-200 text-neutral-900 px-4 h-10">
              All
            </Button>
            <Button
              variant="outline"
              className="rounded-full bg-neutral-900 text-[#a1a1a1] border-white/10 border-0 border-solid px-4 h-10"
            >
              Platform
            </Button>
            <Button
              variant="outline"
              className="rounded-full bg-neutral-900 text-[#a1a1a1] border-white/10 border-0 border-solid px-4 h-10"
            >
              Category
            </Button>
            <Button
              variant="outline"
              className="rounded-full bg-neutral-900 text-[#a1a1a1] border-white/10 border-0 border-solid px-4 h-10"
            >
              Web
            </Button>
            <Button
              variant="outline"
              className="rounded-full bg-neutral-900 text-[#a1a1a1] border-white/10 border-0 border-solid px-4 h-10"
            >
              Backend
            </Button>
            <Button
              variant="outline"
              className="rounded-full bg-neutral-900 text-[#a1a1a1] border-white/10 border-0 border-solid px-4 h-10"
            >
              Data
            </Button>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardHeader className="p-0 gap-3">
                <div className="flex justify-between items-center gap-3">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Web · Checkout
                  </span>
                  <div className="flex flex-col items-end gap-1">
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.696_0.17_162.48)] rounded-full text-xs leading-4 px-3 py-1">
                      Helpful 42
                    </span>
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.627_0.265_303.9)] rounded-full text-xs leading-4 px-3 py-1">
                      Fixed it 18
                    </span>
                  </div>
                </div>
                <CardTitle className="text-xl leading-7">
                  Payment gateway timeout causing retry storms
                </CardTitle>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <p className="text-[#a1a1a1] text-sm leading-6">
                  Timeouts on downstream payment providers triggered repeated
                  retries and queue buildup.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Platform: Web
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Category: Reliability
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Pipeline: Payments
                  </span>
                </div>
                <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                  <span>Occurrences: 42</span>
                  <span>Last seen: Jul 14, 2026</span>
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardHeader className="p-0 gap-3">
                <div className="flex justify-between items-center gap-3">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Data · Schema
                  </span>
                  <div className="flex flex-col items-end gap-1">
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.696_0.17_162.48)] rounded-full text-xs leading-4 px-3 py-1">
                      Helpful 31
                    </span>
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.627_0.265_303.9)] rounded-full text-xs leading-4 px-3 py-1">
                      Fixed it 12
                    </span>
                  </div>
                </div>
                <CardTitle className="text-xl leading-7">
                  Schema drift in profile sync jobs
                </CardTitle>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <p className="text-[#a1a1a1] text-sm leading-6">
                  Upstream column changes caused ingestion failures until
                  contracts were tightened.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Platform: GCP
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Category: Data Quality
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Pipeline: profile-sync
                  </span>
                </div>
                <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                  <span>Occurrences: 31</span>
                  <span>Last seen: Jul 12, 2026</span>
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardHeader className="p-0 gap-3">
                <div className="flex justify-between items-center gap-3">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Infra · Capacity
                  </span>
                  <div className="flex flex-col items-end gap-1">
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.696_0.17_162.48)] rounded-full text-xs leading-4 px-3 py-1">
                      Helpful 27
                    </span>
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.627_0.265_303.9)] rounded-full text-xs leading-4 px-3 py-1">
                      Fixed it 9
                    </span>
                  </div>
                </div>
                <CardTitle className="text-xl leading-7">
                  Worker pool exhaustion during peak traffic
                </CardTitle>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <p className="text-[#a1a1a1] text-sm leading-6">
                  Burst traffic saturated workers and increased queue depth
                  until autoscaling recovered.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Platform: Backend
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Category: Infra
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Pipeline: checkout-stream
                  </span>
                </div>
                <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                  <span>Occurrences: 27</span>
                  <span>Last seen: Jul 10, 2026</span>
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardHeader className="p-0 gap-3">
                <div className="flex justify-between items-center gap-3">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    API · Latency
                  </span>
                  <div className="flex flex-col items-end gap-1">
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.696_0.17_162.48)] rounded-full text-xs leading-4 px-3 py-1">
                      Helpful 19
                    </span>
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.627_0.265_303.9)] rounded-full text-xs leading-4 px-3 py-1">
                      Fixed it 7
                    </span>
                  </div>
                </div>
                <CardTitle className="text-xl leading-7">
                  External API latency spikes causing cascading retries
                </CardTitle>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <p className="text-[#a1a1a1] text-sm leading-6">
                  Slow third-party responses amplified retry pressure and
                  degraded checkout throughput.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Platform: AWS
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Category: Reliability
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Pipeline: payments-api
                  </span>
                </div>
                <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                  <span>Occurrences: 19</span>
                  <span>Last seen: Jul 08, 2026</span>
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardHeader className="p-0 gap-3">
                <div className="flex justify-between items-center gap-3">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Analytics · Freshness
                  </span>
                  <div className="flex flex-col items-end gap-1">
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.696_0.17_162.48)] rounded-full text-xs leading-4 px-3 py-1">
                      Helpful 24
                    </span>
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.627_0.265_303.9)] rounded-full text-xs leading-4 px-3 py-1">
                      Fixed it 11
                    </span>
                  </div>
                </div>
                <CardTitle className="text-xl leading-7">
                  Late-arriving data in nightly aggregation jobs
                </CardTitle>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <p className="text-[#a1a1a1] text-sm leading-6">
                  Delayed source feeds caused stale dashboards until the
                  schedule was adjusted.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Platform: Snowflake
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Category: Freshness
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Pipeline: nightly-agg
                  </span>
                </div>
                <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                  <span>Occurrences: 24</span>
                  <span>Last seen: Jul 06, 2026</span>
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardHeader className="p-0 gap-3">
                <div className="flex justify-between items-center gap-3">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Database · Nulls
                  </span>
                  <div className="flex flex-col items-end gap-1">
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.696_0.17_162.48)] rounded-full text-xs leading-4 px-3 py-1">
                      Helpful 15
                    </span>
                    <span className="bg-[oklch(0.269_0_0)] text-[oklch(0.627_0.265_303.9)] rounded-full text-xs leading-4 px-3 py-1">
                      Fixed it 5
                    </span>
                  </div>
                </div>
                <CardTitle className="text-xl leading-7">
                  Null spikes in transaction amount column
                </CardTitle>
              </CardHeader>
              <CardContent className="flex p-0 flex-col gap-4">
                <p className="text-[#a1a1a1] text-sm leading-6">
                  A malformed upstream payload introduced null values that broke
                  downstream reporting.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Platform: AWS
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Category: Data Quality
                  </span>
                  <span className="rounded-full bg-neutral-800 text-[#a1a1a1] text-xs leading-4 border-white/10 border-1 border-solid px-3 py-1">
                    Pipeline: tx-loader
                  </span>
                </div>
                <div className="text-[#a1a1a1] text-xs leading-4 flex justify-between items-center">
                  <span>Occurrences: 15</span>
                  <span>Last seen: Jul 03, 2026</span>
                </div>
              </CardContent>
            </Card>
          </div>
          <Card className="text-center rounded-3xl bg-neutral-900 border-white/10 border-0 border-dashed flex p-12 justify-center items-center gap-4">
            <CardContent className="flex p-0 flex-col items-center gap-4">
              <div className="size-12 rounded-full bg-neutral-800 text-[#a1a1a1] flex justify-center items-center">
                <BookOpen className="size-6" />
              </div>
              <div className="flex flex-col gap-2">
                <h2 className="font-semibold text-xl leading-7">
                  No knowledge entries yet
                </h2>
                <p className="text-[#a1a1a1] text-sm leading-5">
                  Feedback from resolved incidents will populate this page
                </p>
              </div>
            </CardContent>
          </Card>
          <div className="grid grid-cols-3 gap-4">
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardContent className="flex p-0 flex-col gap-3">
                <div className="w-2/3 rounded-sm bg-neutral-800 h-4" />
                <div className="w-5/6 rounded-sm bg-neutral-800 h-4" />
                <div className="w-4/5 rounded-sm bg-neutral-800 h-4" />
                <div className="w-3/4 rounded-sm bg-neutral-800 h-4" />
                <div className="flex pt-2 gap-2">
                  <div className="rounded-full bg-neutral-800 w-16 h-6" />
                  <div className="rounded-full bg-neutral-800 w-20 h-6" />
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardContent className="flex p-0 flex-col gap-3">
                <div className="w-1/2 rounded-sm bg-neutral-800 h-4" />
                <div className="w-3/4 rounded-sm bg-neutral-800 h-4" />
                <div className="w-2/3 rounded-sm bg-neutral-800 h-4" />
                <div className="w-5/6 rounded-sm bg-neutral-800 h-4" />
                <div className="flex pt-2 gap-2">
                  <div className="rounded-full bg-neutral-800 w-20 h-6" />
                  <div className="rounded-full bg-neutral-800 w-16 h-6" />
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-2xl bg-neutral-900 border-white/10 border-0 border-solid p-5 gap-4">
              <CardContent className="flex p-0 flex-col gap-3">
                <div className="w-3/5 rounded-sm bg-neutral-800 h-4" />
                <div className="w-4/5 rounded-sm bg-neutral-800 h-4" />
                <div className="w-2/3 rounded-sm bg-neutral-800 h-4" />
                <div className="w-5/6 rounded-sm bg-neutral-800 h-4" />
                <div className="flex pt-2 gap-2">
                  <div className="rounded-full bg-neutral-800 w-14 h-6" />
                  <div className="rounded-full bg-neutral-800 w-18 h-6" />
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
